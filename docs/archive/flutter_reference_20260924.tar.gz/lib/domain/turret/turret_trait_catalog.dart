import 'turret_trait_type.dart';
import 'turret_type.dart';

class TurretTraitSet {
  const TurretTraitSet({required this.primary, required this.secondary});

  final List<TurretTraitType> primary;
  final List<TurretTraitType> secondary;

  bool get hasChoices => primary.isNotEmpty || secondary.isNotEmpty;
}

const _emptyTurretTraitSet = TurretTraitSet(primary: [], secondary: []);

const turretTraitCatalog = <TurretType, TurretTraitSet>{
  TurretType.arrow: TurretTraitSet(
    primary: [
      TurretTraitType.overheatMagazine,
      TurretTraitType.lightweightBarrel,
    ],
    secondary: [TurretTraitType.suppressiveFire, TurretTraitType.chainCleanup],
  ),
  TurretType.cannon: TurretTraitSet(
    primary: [TurretTraitType.shrapnelShell, TurretTraitType.compressedCharge],
    secondary: [
      TurretTraitType.expandedBlastCore,
      TurretTraitType.fractureImpact,
    ],
  ),
  TurretType.magic: TurretTraitSet(
    primary: [TurretTraitType.highHeatBurn, TurretTraitType.lingeringEmbers],
    secondary: [TurretTraitType.ignitionBurst, TurretTraitType.chainIgnition],
  ),
  TurretType.frost: TurretTraitSet(
    primary: [TurretTraitType.coolingCycle, TurretTraitType.spreadingChill],
    secondary: [TurretTraitType.frostCrack, TurretTraitType.rapidCooling],
  ),
  TurretType.sniper: TurretTraitSet(
    primary: [TurretTraitType.deadeyeFocus, TurretTraitType.quickScope],
    secondary: [TurretTraitType.exposedMark, TurretTraitType.finishingShot],
  ),
  TurretType.lightning: TurretTraitSet(
    primary: [TurretTraitType.branchCurrent, TurretTraitType.focusedLightning],
    secondary: [
      TurretTraitType.lightningRecovery,
      TurretTraitType.currentAmplification,
    ],
  ),
};

TurretTraitSet turretTraitSetFor(TurretType type) {
  return turretTraitCatalog[type] ?? _emptyTurretTraitSet;
}
