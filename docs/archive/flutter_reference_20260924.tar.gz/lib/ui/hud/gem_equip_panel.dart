import 'package:flutter/material.dart';

import '../../data/definitions/game_gem_data.dart';
import '../../data/definitions/game_turret_data.dart';
import '../../domain/combat/game_phase.dart';
import '../../domain/gem/gem_equip_rules.dart';
import '../../domain/gem/gem_type.dart';
import '../../domain/turret/turret_definition.dart';
import '../../domain/turret/turret_target_priority.dart';
import '../../game/game_snapshot.dart';
import '../../game/rune_nexus_game.dart';
import '../game/game_ui.dart';
import 'gem_socket_section.dart';
import 'hud_common.dart';
import 'turret_trait_panel.dart';

class HudGemEquipPanel extends StatefulWidget {
  const HudGemEquipPanel({
    required this.game,
    required this.snapshot,
    super.key,
  });

  final RuneNexusGame game;
  final GameSnapshot snapshot;

  @override
  State<HudGemEquipPanel> createState() => _GemEquipPanelState();
}

enum _TurretTab { stats, gems }

class _GemEquipPanelState extends State<HudGemEquipPanel> {
  GemType? _selectedInventoryGem;
  _TurretTab _activeTab = _TurretTab.stats;
  final _inventoryScrollController = ScrollController();

  @override
  void didUpdateWidget(covariant HudGemEquipPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.snapshot.selectedTurretPoint !=
        widget.snapshot.selectedTurretPoint) {
      _selectedInventoryGem = null;
    }
  }

  @override
  void dispose() {
    _inventoryScrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final snapshot = widget.snapshot;
    final canInstallGems =
        snapshot.phase == GamePhase.preparation ||
        snapshot.phase == GamePhase.wave;
    final canRemoveGems = canInstallGems;
    final canLevelUp =
        snapshot.phase == GamePhase.preparation ||
        snapshot.phase == GamePhase.wave;
    final canRefund = snapshot.selectedTurretPoint != null && canLevelUp;
    final levelUpPreviewActive = snapshot.selectedTurretLevelUpPreviewActive;
    final definition = gameTurrets[snapshot.selectedTurretType]!;
    final inventory = GemType.values
        .where((type) => (snapshot.gemInventory[type] ?? 0) > 0)
        .toList();
    final selectedSlotIndex = snapshot.selectedTurretGemSlotIndex;
    final selectedSlotGem =
        selectedSlotIndex != null &&
            selectedSlotIndex < snapshot.selectedTurretGems.length
        ? snapshot.selectedTurretGems[selectedSlotIndex]
        : null;
    final selectedInventoryGem =
        _selectedInventoryGem != null &&
            inventory.contains(_selectedInventoryGem)
        ? _selectedInventoryGem
        : null;
    final selectedInventoryGemDefinition = selectedInventoryGem == null
        ? null
        : gameGems[selectedInventoryGem]!;
    final selectedInventoryEquipped =
        selectedInventoryGem != null &&
        snapshot.selectedTurretGems.contains(selectedInventoryGem);
    final selectedSlotCanAcceptGem =
        selectedSlotIndex != null && canInstallGems;
    final selectedInventoryBlockReason = selectedInventoryGem == null
        ? null
        : gemEquipBlockReason(selectedInventoryGem, definition);
    final selectedInventoryInstallBlockReason = selectedInventoryEquipped
        ? '이미 이 포탑에 장착됨'
        : !selectedSlotCanAcceptGem
        ? '링크 홈을 선택하세요'
        : selectedInventoryBlockReason;
    final selectedInventoryCanInstall =
        selectedInventoryGem != null &&
        selectedSlotCanAcceptGem &&
        !selectedInventoryEquipped &&
        selectedInventoryBlockReason == null;
    final showGemInventory = canInstallGems;

    // 레벨업 미리보기 중에는 스탯 변화를 봐야 하므로 스탯 탭을 강제한다.
    final activeTab = levelUpPreviewActive ? _TurretTab.stats : _activeTab;

    final statsBody = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        // 포탑 태그를 위로 올리고 누적 피해는 같은 줄 오른쪽으로 정렬.
        Row(
          children: [
            Expanded(child: HudTurretAttributeChips(definition: definition)),
            const SizedBox(width: 8),
            _DamageSummaryRow(snapshot: snapshot),
          ],
        ),
        const SizedBox(height: 7),
        _TurretStats(snapshot: snapshot, definition: definition),
      ],
    );

    final gemsBody = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        HudTurretLinkSocketStrip(
          snapshot: snapshot,
          maxSlotLimit: widget.game.maxTurretLinkSlotLimit,
          canInstallGems: canInstallGems,
          selectedSlotIndex: selectedSlotIndex,
          onSelectSlot: widget.game.selectSelectedTurretGemSlot,
          onUpgradeLink: widget.game.upgradeSelectedTurretLink,
        ),
        if (showGemInventory && selectedSlotGem != null) ...[
          const SizedBox(height: 6),
          HudSelectedSlotGemActions(
            type: selectedSlotGem,
            turret: definition,
            onRemove: canRemoveGems
                ? widget.game.removeSelectedTurretGemSlot
                : null,
          ),
        ],
        if (showGemInventory) ...[
          const SizedBox(height: 6),
          if (inventory.isEmpty)
            const Text(
              '보유 젬 없음',
              style: TextStyle(fontSize: 12, color: Color(0xFF8AA6B8)),
            )
          else
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '보유 젬',
                  style: TextStyle(fontSize: 12, color: Color(0xFF8AA6B8)),
                ),
                const SizedBox(height: 5),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.fromLTRB(4, 4, 4, 2),
                  decoration: BoxDecoration(
                    color: const Color(0x8807111D),
                    border: Border.all(color: const Color(0x554A6172)),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: ScrollConfiguration(
                    behavior: ScrollConfiguration.of(
                      context,
                    ).copyWith(scrollbars: false),
                    child: SingleChildScrollView(
                      key: const ValueKey('gem-inventory-scroll'),
                      controller: _inventoryScrollController,
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: inventory.map((type) {
                          final gem = gameGems[type]!;
                          final count = snapshot.gemInventory[type]!;
                          final equipped = snapshot.selectedTurretGems.contains(
                            type,
                          );
                          final selected = selectedInventoryGem == type;
                          final blockReason = gemEquipBlockReason(
                            type,
                            definition,
                          );
                          final canInstall =
                              selectedSlotCanAcceptGem &&
                              !equipped &&
                              blockReason == null;
                          return Padding(
                            padding: EdgeInsets.only(
                              right: type == inventory.last ? 0 : 6,
                            ),
                            child: HudInventoryGemSlot(
                              gem: gem,
                              count: count,
                              selected: selected,
                              equipped: equipped,
                              blocked: blockReason != null,
                              enabled: canInstallGems,
                              onTap: () {
                                if (!canInstallGems) {
                                  return;
                                }
                                if (selected && canInstall) {
                                  widget.game.equipSelectedTurret(type);
                                  setState(() {
                                    _selectedInventoryGem = null;
                                  });
                                  return;
                                }
                                setState(() {
                                  _selectedInventoryGem = type;
                                });
                              },
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ),
                if (selectedInventoryGem != null &&
                    selectedInventoryGemDefinition != null) ...[
                  const SizedBox(height: 6),
                  HudSelectedInventoryGemActions(
                    type: selectedInventoryGem,
                    turret: definition,
                    gem: selectedInventoryGemDefinition,
                    blockReason: selectedInventoryInstallBlockReason,
                    canInstall: selectedInventoryCanInstall,
                    enabled: canInstallGems,
                    onInstall: () {
                      widget.game.equipSelectedTurret(selectedInventoryGem);
                      setState(() {
                        _selectedInventoryGem = null;
                      });
                    },
                  ),
                ],
              ],
            ),
        ],
      ],
    );

    // 패널이 전장을 끝없이 덮지 않도록 본문 높이를 화면 비율로 제한하고 내부 스크롤.
    final maxBodyHeight = (MediaQuery.sizeOf(context).height * 0.28).clamp(
      150.0,
      280.0,
    );

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: const Color(0xAA0B1B2B),
        border: Border.all(color: const Color(0x5533D8FF)),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Expanded(
                child: Wrap(
                  spacing: 6,
                  runSpacing: 3,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Text(
                      '${snapshot.selectedTurretName} 포탑',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFFE8F8FF),
                      ),
                    ),
                    Text.rich(
                      TextSpan(
                        children: [
                          const TextSpan(
                            text: 'LV ',
                            style: TextStyle(
                              fontSize: 8,
                              color: Color(0xFF8AA6B8),
                            ),
                          ),
                          TextSpan(
                            text: '${snapshot.selectedTurretLevel}',
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                              color: Color(0xFFE7C66A),
                            ),
                          ),
                          TextSpan(
                            text: levelUpPreviewActive
                                ? ' → ${snapshot.selectedTurretNextLevel}'
                                : ' / ${snapshot.selectedTurretMaxLevel}',
                            style: TextStyle(
                              fontSize: levelUpPreviewActive ? 14 : 9,
                              fontWeight: levelUpPreviewActive
                                  ? FontWeight.w900
                                  : FontWeight.w600,
                              color: levelUpPreviewActive
                                  ? GamePalette.green
                                  : const Color(0xFF8AA6B8),
                            ),
                          ),
                        ],
                      ),
                      semanticsLabel: levelUpPreviewActive
                          ? '레벨 ${snapshot.selectedTurretLevel}, 다음 레벨 ${snapshot.selectedTurretNextLevel}'
                          : '레벨 ${snapshot.selectedTurretLevel}, 최대 ${snapshot.selectedTurretMaxLevel}',
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              _TurretActionBar(
                canLevelUp:
                    snapshot.selectedTurretCanLevelUp &&
                    canLevelUp &&
                    snapshot.gold >= snapshot.selectedTurretLevelUpCost,
                levelUpLabel: snapshot.selectedTurretCanLevelUp
                    ? '${snapshot.selectedTurretLevelUpCost}G'
                    : 'MAX',
                levelUpPreviewActive: levelUpPreviewActive,
                onLevelUp: widget.game.previewOrLevelUpSelectedTurret,
                canRefund: canRefund,
                refundLabel: '${snapshot.selectedTurretRefundGold}G',
                onRefund: () => _confirmRefundSelectedTurret(snapshot),
                traitButton: snapshot.selectedTurretSupportsTraits
                    ? HudTurretTraitActionButton(
                        snapshot: snapshot,
                        onPressed: () => _showTraitDialog(snapshot),
                      )
                    : null,
              ),
            ],
          ),
          const SizedBox(height: 5),
          _TurretInspectorTabs(
            activeTab: activeTab,
            onSelect: (tab) => setState(() => _activeTab = tab),
          ),
          if (snapshot.canSetTurretTargetPriority &&
              activeTab == _TurretTab.stats) ...[
            const SizedBox(height: 6),
            _TurretTargetPrioritySelector(
              priority: snapshot.selectedTurretTargetPriority,
              onSelected: widget.game.setSelectedTurretTargetPriority,
            ),
          ],
          const SizedBox(height: 6),
          ConstrainedBox(
            constraints: BoxConstraints(maxHeight: maxBodyHeight),
            child: SingleChildScrollView(
              child: activeTab == _TurretTab.stats ? statsBody : gemsBody,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmRefundSelectedTurret(GameSnapshot snapshot) async {
    final pauseCombat = snapshot.phase == GamePhase.wave;
    if (pauseCombat) {
      widget.game.pauseEngine();
    }
    try {
      final confirmed = await showGameDialog<bool>(
        context: context,
        builder: (context) => _TurretRefundConfirmDialog(snapshot: snapshot),
      );
      if (!mounted || confirmed != true) {
        return;
      }

      widget.game.refundSelectedTurret();
    } finally {
      if (pauseCombat) {
        widget.game.resumeEngine();
      }
    }
  }

  Future<void> _showTraitDialog(GameSnapshot snapshot) async {
    final pauseCombat = snapshot.phase == GamePhase.wave;
    if (pauseCombat) {
      widget.game.pauseEngine();
    }
    try {
      final selected = await showGameDialog<HudTraitSelection>(
        context: context,
        builder: (context) => HudTurretTraitDialog(snapshot: snapshot),
      );
      if (!mounted || selected == null) {
        return;
      }

      if (selected.tier == 1) {
        widget.game.chooseSelectedTurretPrimaryTrait(selected.trait);
      } else {
        widget.game.chooseSelectedTurretSecondaryTrait(selected.trait);
      }
    } finally {
      if (pauseCombat) {
        widget.game.resumeEngine();
      }
    }
  }
}

class _TurretInspectorTabs extends StatelessWidget {
  const _TurretInspectorTabs({required this.activeTab, required this.onSelect});

  final _TurretTab activeTab;
  final ValueChanged<_TurretTab> onSelect;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: _tab(_TurretTab.stats, Icons.bar_chart_rounded, '스탯')),
        Expanded(
          child: _tab(_TurretTab.gems, Icons.diamond_outlined, '젬 · 링크'),
        ),
      ],
    );
  }

  Widget _tab(_TurretTab tab, IconData icon, String label) {
    final selected = activeTab == tab;
    final foreground = selected
        ? GamePalette.textPrimary
        : GamePalette.textSecondary;
    return Semantics(
      selected: selected,
      button: true,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => onSelect(tab),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(5)),
          child: Container(
            height: 28,
            decoration: BoxDecoration(
              color: selected
                  ? const Color(0xAA173548)
                  : const Color(0x6607111D),
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(5),
              ),
              border: Border(
                top: BorderSide(
                  color: selected ? GamePalette.cyan : GamePalette.metalDim,
                ),
                left: BorderSide(
                  color: selected ? GamePalette.cyan : GamePalette.metalDim,
                ),
                right: BorderSide(
                  color: selected ? GamePalette.cyan : GamePalette.metalDim,
                ),
                bottom: BorderSide(
                  color: selected ? GamePalette.cyan : GamePalette.metalDim,
                  width: selected ? 2 : 1,
                ),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 14, color: foreground),
                const SizedBox(width: 5),
                Text(
                  label,
                  style: GameTextStyles.withColor(
                    GameTextStyles.buttonSmall,
                    foreground,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TurretTargetPrioritySelector extends StatelessWidget {
  const _TurretTargetPrioritySelector({
    required this.priority,
    required this.onSelected,
  });

  final TurretTargetPriority priority;
  final ValueChanged<TurretTargetPriority> onSelected;

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<TurretTargetPriority>(
      key: const ValueKey('turret-target-priority-selector'),
      tooltip: '공격 명령 변경',
      color: const Color(0xFF0B1827),
      offset: const Offset(0, -190),
      shape: RoundedRectangleBorder(
        side: const BorderSide(color: Color(0x8833D8FF)),
        borderRadius: BorderRadius.circular(8),
      ),
      onSelected: onSelected,
      itemBuilder: (context) {
        return TurretTargetPriority.values.map((value) {
          final selected = value == priority;
          return PopupMenuItem(
            value: value,
            child: Row(
              children: [
                Icon(
                  selected ? Icons.radio_button_checked : Icons.adjust,
                  size: 16,
                  color: selected
                      ? const Color(0xFF8EE6FF)
                      : const Color(0xFF607587),
                ),
                const SizedBox(width: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      _targetPriorityLabel(value),
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFFE8F8FF),
                      ),
                    ),
                    Text(
                      _targetPriorityDescription(value),
                      style: const TextStyle(
                        fontSize: 10,
                        color: Color(0xFF8AA6B8),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        }).toList();
      },
      child: Container(
        height: 32,
        padding: const EdgeInsets.only(left: 9, right: 3),
        decoration: BoxDecoration(
          color: const Color(0x9907111D),
          border: Border.all(color: const Color(0x5533D8FF)),
          borderRadius: BorderRadius.circular(7),
        ),
        child: Row(
          children: [
            const Icon(Icons.ads_click, size: 14, color: Color(0xFF8EE6FF)),
            const SizedBox(width: 6),
            const Text(
              '공격 명령',
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w800,
                color: Color(0xFF8AA6B8),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                _targetPriorityLabel(priority),
                maxLines: 1,
                overflow: TextOverflow.clip,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  color: Color(0xFFE8F8FF),
                ),
              ),
            ),
            const SizedBox(
              height: 28,
              width: 34,
              child: Icon(
                Icons.keyboard_arrow_down,
                size: 20,
                color: Color(0xFF8EE6FF),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

String _targetPriorityLabel(TurretTargetPriority priority) {
  return switch (priority) {
    TurretTargetPriority.first => '선두 적',
    TurretTargetPriority.last => '후방 적',
    TurretTargetPriority.strongest => '강한 적',
    TurretTargetPriority.weakest => '약한 적',
    TurretTargetPriority.nearest => '가까운 적',
  };
}

String _targetPriorityDescription(TurretTargetPriority priority) {
  return switch (priority) {
    TurretTargetPriority.first => '경로 앞쪽 우선',
    TurretTargetPriority.last => '뒤처진 적 우선',
    TurretTargetPriority.strongest => '현재 내구도 높은 적',
    TurretTargetPriority.weakest => '현재 내구도 낮은 적',
    TurretTargetPriority.nearest => '포탑에 가까운 적',
  };
}

class _TurretActionBar extends StatelessWidget {
  const _TurretActionBar({
    required this.canLevelUp,
    required this.levelUpLabel,
    required this.levelUpPreviewActive,
    required this.onLevelUp,
    required this.canRefund,
    required this.refundLabel,
    required this.onRefund,
    this.traitButton,
  });

  final bool canLevelUp;
  final String levelUpLabel;
  final bool levelUpPreviewActive;
  final VoidCallback onLevelUp;
  final bool canRefund;
  final String refundLabel;
  final VoidCallback onRefund;
  final Widget? traitButton;

  @override
  Widget build(BuildContext context) {
    return FittedBox(
      fit: BoxFit.scaleDown,
      alignment: Alignment.centerRight,
      child: Row(
        children: [
          _TurretActionButton(
            icon: Icons.trending_up,
            label: levelUpLabel,
            color: const Color(0xFFE7C66A),
            highlighted: levelUpPreviewActive,
            onPressed: canLevelUp ? onLevelUp : null,
          ),
          const SizedBox(width: 6),
          _TurretActionButton(
            icon: Icons.sell_outlined,
            label: refundLabel,
            color: const Color(0xFFFF8A2A),
            onPressed: canRefund ? onRefund : null,
          ),
          if (traitButton != null) ...[const SizedBox(width: 6), traitButton!],
        ],
      ),
    );
  }
}

class _TurretActionButton extends StatelessWidget {
  const _TurretActionButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.onPressed,
    this.highlighted = false,
  });

  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback? onPressed;
  final bool highlighted;

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null;
    final activeHighlight = enabled && highlighted;
    final foreground = enabled
        ? (activeHighlight ? const Color(0xFF07111D) : color)
        : const Color(0xFF607587);
    return SizedBox(
      height: 30,
      child: OutlinedButton(
        onPressed: onPressed,
        style: OutlinedButton.styleFrom(
          foregroundColor: foreground,
          disabledForegroundColor: const Color(0xFF607587),
          backgroundColor: activeHighlight
              ? color.withValues(alpha: 0.82)
              : Colors.transparent,
          side: BorderSide(
            color: activeHighlight
                ? const Color(0xFFE8F8FF)
                : enabled
                ? color.withValues(alpha: 0.82)
                : const Color(0x5533D8FF),
            width: activeHighlight ? 1.4 : 1,
          ),
          padding: const EdgeInsets.symmetric(horizontal: 6),
          minimumSize: const Size(44, 30),
          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(7)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 14),
            const SizedBox(width: 4),
            Text(
              label,
              style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800),
            ),
          ],
        ),
      ),
    );
  }
}

class _TurretRefundConfirmDialog extends StatelessWidget {
  const _TurretRefundConfirmDialog({required this.snapshot});

  final GameSnapshot snapshot;

  @override
  Widget build(BuildContext context) {
    final gemCount = snapshot.selectedTurretGems.whereType<GemType>().length;
    final traitWarning = snapshot.selectedTurretPrimaryTrait == null
        ? ''
        : '\n특성에 사용한 젬 파편은 반환되지 않습니다.';
    return GameModalFrame(
      maxWidth: 340,
      tone: GameModalTone.danger,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              const Icon(
                Icons.sell_outlined,
                color: GamePalette.danger,
                size: 20,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  '${snapshot.selectedTurretName ?? '선택한'} 포탑 환불',
                  style: GameTextStyles.title,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            '설치 및 업그레이드 비용의 ${snapshot.turretRefundPercent}%인 '
            '${snapshot.selectedTurretRefundGold}골드를 돌려받습니다.'
            '${gemCount > 0 ? '\n장착된 젬 $gemCount개는 인벤토리로 반환됩니다.' : ''}'
            '$traitWarning',
            style: GameTextStyles.body.copyWith(height: 1.35),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: GameButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  label: '취소',
                  variant: GameButtonVariant.ghost,
                  accentColor: GamePalette.metal,
                  height: 38,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: GameButton(
                  onPressed: () => Navigator.of(context).pop(true),
                  label: '환불',
                  variant: GameButtonVariant.danger,
                  accentColor: GamePalette.danger,
                  height: 38,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _DamageSummaryRow extends StatelessWidget {
  const _DamageSummaryRow({required this.snapshot});

  final GameSnapshot snapshot;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _showDamageDetailDialog(context, snapshot),
          borderRadius: BorderRadius.circular(7),
          child: Container(
            height: 30,
            padding: const EdgeInsets.only(left: 9, right: 4),
            decoration: BoxDecoration(
              color: const Color(0x9907111D),
              border: Border.all(color: const Color(0x5533D8FF)),
              borderRadius: BorderRadius.circular(7),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  '누적 피해',
                  style: TextStyle(fontSize: 10, color: Color(0xFF8AA6B8)),
                ),
                const SizedBox(width: 7),
                Text(
                  hudFormatDamageValue(snapshot.selectedTurretDamageDealt),
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFFE8F8FF),
                  ),
                ),
                const SizedBox(width: 3),
                const Icon(
                  Icons.more_horiz,
                  size: 17,
                  color: Color(0xFF8EE6FF),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showDamageDetailDialog(BuildContext context, GameSnapshot snapshot) {
    showGameDialog<void>(
      context: context,
      builder: (context) {
        return GameModalFrame(
          maxWidth: 356,
          accentColor: GamePalette.cyan,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Row(
                children: [
                  Icon(
                    Icons.query_stats_outlined,
                    color: GamePalette.cyan,
                    size: 20,
                  ),
                  SizedBox(width: 8),
                  Expanded(child: Text('피해 기록', style: GameTextStyles.title)),
                ],
              ),
              const SizedBox(height: 12),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _DamageDetailLine(
                    label: '총 피해',
                    value: snapshot.selectedTurretDamageDealt,
                    highlighted: true,
                  ),
                  _DamageDetailLine(
                    label: '직접 피해',
                    value: snapshot.selectedTurretDirectDamageDealt,
                  ),
                  _DamageDetailLine(
                    label: '범위 피해',
                    value: snapshot.selectedTurretSplashDamageDealt,
                  ),
                  _DamageDetailLine(
                    label: '연쇄 피해',
                    value: snapshot.selectedTurretChainDamageDealt,
                  ),
                  _DamageDetailLine(
                    label: '화상 피해',
                    value: snapshot.selectedTurretBurnDamageDealt,
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Align(
                alignment: Alignment.centerRight,
                child: SizedBox(
                  width: 86,
                  child: GameButton(
                    onPressed: () => Navigator.of(context).pop(),
                    label: '닫기',
                    variant: GameButtonVariant.ghost,
                    accentColor: GamePalette.metal,
                    height: 38,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _DamageDetailLine extends StatelessWidget {
  const _DamageDetailLine({
    required this.label,
    required this.value,
    this.highlighted = false,
  });

  final String label;
  final double value;
  final bool highlighted;

  @override
  Widget build(BuildContext context) {
    if (highlighted) {
      return Container(
        margin: const EdgeInsets.only(bottom: 7),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0x5533D8FF),
          border: Border.all(color: const Color(0x9933D8FF)),
          borderRadius: BorderRadius.circular(7),
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                  fontSize: 12,
                  color: Color(0xFFE0F4FF),
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            Text(
              hudFormatDamageValue(value),
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w900,
                color: Color(0xFF8EE6FF),
              ),
            ),
          ],
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(fontSize: 12, color: Color(0xFF8AA6B8)),
            ),
          ),
          Text(
            hudFormatDamageValue(value),
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: Color(0xFFE8F8FF),
            ),
          ),
        ],
      ),
    );
  }
}

class _TurretStats extends StatelessWidget {
  const _TurretStats({required this.snapshot, required this.definition});

  final GameSnapshot snapshot;
  final TurretDefinition definition;

  @override
  Widget build(BuildContext context) {
    final previewActive = snapshot.selectedTurretLevelUpPreviewActive;
    final multipleProjectiles =
        definition.firesProjectile &&
        snapshot.selectedTurretProjectileCount > 1;
    final dps = snapshot.selectedTurretAttackRate <= 0
        ? 0.0
        : snapshot.selectedTurretDamage * snapshot.selectedTurretAttackRate;
    final nextDps = snapshot.selectedTurretNextAttackRate <= 0
        ? 0.0
        : snapshot.selectedTurretNextDamage *
              snapshot.selectedTurretNextAttackRate;
    final burnDps = snapshot.selectedTurretBurnDamagePerSecond;
    final totalDps = dps + burnDps;
    final nextTotalDps =
        nextDps + snapshot.selectedTurretNextBurnDamagePerSecond;
    const critColor = Color(0xFFE7C66A);

    // 공격 지표와 보조 지표를 짝지은 2열 수치표.
    final cells = <Widget>[
      _TurretStatEntry(
        label: multipleProjectiles ? '탄당 피해' : '피해',
        value: snapshot.selectedTurretDamage.toStringAsFixed(1),
        valueChild: previewActive
            ? _PreviewStatValue(
                current: snapshot.selectedTurretDamage.toStringAsFixed(1),
                next: snapshot.selectedTurretNextDamage.toStringAsFixed(1),
              )
            : null,
      ),
      _TurretStatEntry(
        label: multipleProjectiles ? '탄당 DPS' : 'DPS',
        value: totalDps.toStringAsFixed(1),
        valueChild: previewActive
            ? _PreviewStatValue(
                current: totalDps.toStringAsFixed(1),
                next: nextTotalDps.toStringAsFixed(1),
              )
            : burnDps > 0
            ? RichText(
                text: TextSpan(
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFFE8F8FF),
                  ),
                  children: [
                    TextSpan(text: dps.toStringAsFixed(1)),
                    TextSpan(
                      text: ' +${burnDps.toStringAsFixed(1)}',
                      style: const TextStyle(color: Color(0xFFFFA24A)),
                    ),
                  ],
                ),
              )
            : null,
      ),
      _TurretStatEntry(
        label: '초당',
        value: '${snapshot.selectedTurretAttackRate.toStringAsFixed(2)}회',
        valueChild: previewActive
            ? _PreviewStatValue(
                current:
                    '${snapshot.selectedTurretAttackRate.toStringAsFixed(2)}회',
                next:
                    '${snapshot.selectedTurretNextAttackRate.toStringAsFixed(2)}회',
              )
            : null,
      ),
      _TurretStatEntry(
        label: '사거리',
        value: snapshot.selectedTurretRange.round().toString(),
        valueChild: previewActive
            ? _PreviewStatValue(
                current: snapshot.selectedTurretRange.round().toString(),
                next: snapshot.selectedTurretNextRange.round().toString(),
              )
            : null,
      ),
      if (definition.centeredAreaAttack ||
          definition.splashRadius > 0 ||
          snapshot.selectedTurretGems.contains(GemType.explosion))
        _TurretStatEntry(
          label: '효과 범위',
          value:
              '${(snapshot.selectedTurretEffectAreaMultiplier * 100).round()}%',
        ),
      _TurretStatEntry(
        label: '치명 확률',
        value: '${(snapshot.selectedTurretCriticalChance * 100).round()}%',
        accent: critColor,
      ),
      _TurretStatEntry(
        label: '치명 피해',
        value:
            '${(snapshot.selectedTurretCriticalDamageMultiplier * 100).round()}%',
        accent: critColor,
      ),
    ];

    if (definition.firesProjectile) {
      cells.add(
        _TurretStatEntry(
          label: '투사체',
          value: '${snapshot.selectedTurretProjectileCount}발',
        ),
      );
    }
    if (burnDps > 0) {
      cells.add(
        _TurretStatEntry(
          label: '화상',
          value: '${snapshot.selectedTurretBurnDuration.toStringAsFixed(1)}초',
          valueChild: previewActive
              ? _PreviewStatValue(
                  current:
                      '${snapshot.selectedTurretBurnDuration.toStringAsFixed(1)}초',
                  next:
                      '${snapshot.selectedTurretNextBurnDuration.toStringAsFixed(1)}초',
                )
              : null,
        ),
      );
    }
    if (snapshot.selectedTurretSlowDuration > 0) {
      final currentSlow =
          '${((1 - snapshot.selectedTurretSlowMultiplier) * 100).round()}%';
      cells.add(
        _TurretStatEntry(
          label: '감속',
          value: currentSlow,
          valueChild: previewActive
              ? _PreviewStatValue(
                  current: currentSlow,
                  next:
                      '${((1 - snapshot.selectedTurretNextSlowMultiplier) * 100).round()}%',
                )
              : null,
        ),
      );
    }

    const columns = 2;
    final rows = <Widget>[];
    for (var i = 0; i < cells.length; i += columns) {
      final rowChildren = <Widget>[];
      for (var j = 0; j < columns; j++) {
        if (j > 0) {
          rowChildren.add(const SizedBox(width: 16));
        }
        final index = i + j;
        rowChildren.add(
          index < cells.length
              ? Expanded(child: cells[index])
              : const Expanded(child: SizedBox.shrink()),
        );
      }
      if (rows.isNotEmpty) {
        rows.add(
          const Divider(height: 1, thickness: 1, color: Color(0xFF223442)),
        );
      }
      rows.add(Row(children: rowChildren));
    }

    // 추가 스탯도 기본 세 줄 안에서 탐색; 시스템 글자 크기는 반영.
    final rowHeight = (MediaQuery.textScalerOf(context).scale(12) * 1.5 + 6)
        .clamp(24.0, double.infinity);
    return SizedBox(
      height: rowHeight * 3 + 2,
      child: ScrollConfiguration(
        behavior: ScrollConfiguration.of(context).copyWith(scrollbars: false),
        child: SingleChildScrollView(
          key: const ValueKey('turret-stats-scroll'),
          primary: false,
          child: Column(mainAxisSize: MainAxisSize.min, children: rows),
        ),
      ),
    );
  }
}

class _TurretStatEntry extends StatelessWidget {
  const _TurretStatEntry({
    required this.label,
    required this.value,
    this.valueChild,
    this.accent,
  });

  final String label;
  final String value;
  final Widget? valueChild;
  final Color? accent;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Text(
            label,
            style: const TextStyle(fontSize: 10, color: Color(0xFF8AA6B8)),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Align(
              alignment: Alignment.centerRight,
              child:
                  valueChild ??
                  Text(
                    value,
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      color: accent ?? const Color(0xFFE8F8FF),
                    ),
                  ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PreviewStatValue extends StatelessWidget {
  const _PreviewStatValue({required this.current, required this.next});

  final String current;
  final String next;

  @override
  Widget build(BuildContext context) {
    return RichText(
      text: TextSpan(
        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800),
        children: [
          TextSpan(
            text: current,
            style: const TextStyle(color: Color(0xFF8AA6B8)),
          ),
          const TextSpan(
            text: ' → ',
            style: TextStyle(color: Color(0xFF63E6A5)),
          ),
          TextSpan(
            text: next,
            style: const TextStyle(color: Color(0xFFE8F8FF)),
          ),
        ],
      ),
    );
  }
}
