import 'helpers/native_game_test_driver.dart';
import 'helpers/game_balance_test_helpers.dart';

void main() {
  test('claim checks refresh the day before evaluating completed progress', () {
    final beforeReset = DateTime.utc(2026, 6, 7, 19, 59).millisecondsSinceEpoch;
    final afterReset = DateTime.utc(2026, 6, 7, 20).millisecondsSinceEpoch;
    for (final check in <bool Function(RunProgression)>[
      (progression) => progression.canClaimDailyQuestReward(
        DailyQuestType.clearWaves,
        nowMillis: afterReset,
      ),
      (progression) => progression.canClaimDailyQuestAllCompleteReward(
        nowMillis: afterReset,
      ),
      (progression) => progression.canClaimWeeklyQuestReward(
        DailyQuestType.clearWaves,
        nowMillis: afterReset,
      ),
    ]) {
      final progression = RunProgression();
      for (final entry in gameWeeklyQuestDefinitions.entries) {
        progression.recordDailyQuestProgress(
          entry.key,
          amount: entry.value.targetCount,
          nowMillis: beforeReset,
        );
      }
      expect(progression.allDailyQuestsComplete, isTrue);
      expect(progression.allWeeklyQuestsComplete, isTrue);
      expect(check(progression), isFalse);
      expect(progression.dailyQuestProgress, isEmpty);
      expect(progression.weeklyQuestProgress, isEmpty);
      expect(progression.freeDiamonds, 0);
    }
  });

  test('daily receipts preserve period checks without refreshing time', () {
    final nowMillis = DateTime.utc(2026, 6, 8).millisecondsSinceEpoch;
    final progression = RunProgression();
    for (final entry in gameDailyQuestDefinitions.entries) {
      progression.recordDailyQuestProgress(
        entry.key,
        amount: entry.value.targetCount,
        nowMillis: nowMillis,
      );
    }
    final dayKey = progression.dailyQuestDayKey;
    expect(
      progression.applyDailyQuestRewardReceipt(
        DailyQuestType.clearWaves,
        dayKey: dayKey - 1,
      ),
      isFalse,
    );
    expect(
      progression.applyDailyQuestAllCompleteRewardReceipt(dayKey: dayKey - 1),
      isFalse,
    );
    expect(progression.claimedDailyQuestRewards, isEmpty);
    expect(progression.dailyQuestAllCompleteClaimed, isFalse);
    expect(
      progression.applyDailyQuestRewardReceipt(
        DailyQuestType.clearWaves,
        dayKey: dayKey,
      ),
      isTrue,
    );
    expect(
      progression.applyDailyQuestAllCompleteRewardReceipt(dayKey: dayKey),
      isTrue,
    );
    expect(progression.lastDailyQuestSeenMillis, nowMillis);
    expect(progression.freeDiamonds, 0);
  });

  test('daily quests grant free diamonds once and persist state', () {
    const nowMillis = 1780675200000;
    final progression = RunProgression();

    progression.recordDailyQuestProgress(
      DailyQuestType.clearWaves,
      amount: 30,
      nowMillis: nowMillis,
    );

    expect(
      progression.claimDailyQuestReward(
        DailyQuestType.clearWaves,
        nowMillis: nowMillis,
      ),
      isTrue,
    );
    expect(
      progression.claimDailyQuestReward(
        DailyQuestType.clearWaves,
        nowMillis: nowMillis,
      ),
      isFalse,
    );
    expect(progression.freeDiamonds, 20);
    expect(progression.paidDiamonds, 0);

    final saved = SavedProgression.fromJson(progression.toSaveData().toJson());
    final restored = RunProgression()..restoreFromSaveData(saved);

    expect(restored.dailyQuestDayKey, progression.dailyQuestDayKey);
    expect(restored.dailyQuestProgress[DailyQuestType.clearWaves], 30);
    expect(
      restored.claimedDailyQuestRewards,
      contains(DailyQuestType.clearWaves),
    );
    expect(restored.freeDiamonds, 20);
  });

  test(
    'daily all complete reward grants diamonds and a module ticket once',
    () {
      const nowMillis = 1780675200000;
      final progression = RunProgression();

      for (final entry in gameDailyQuestDefinitions.entries) {
        progression.recordDailyQuestProgress(
          entry.key,
          amount: entry.value.targetCount,
          nowMillis: nowMillis,
        );
      }

      expect(progression.completedDailyQuestCount, 4);
      expect(
        progression.claimDailyQuestAllCompleteReward(nowMillis: nowMillis),
        isTrue,
      );
      expect(
        progression.claimDailyQuestAllCompleteReward(nowMillis: nowMillis),
        isFalse,
      );
      expect(progression.freeDiamonds, 40);
      expect(progression.turretModuleTickets, 1);
      final restored = RunProgression()
        ..restoreFromSaveData(
          SavedProgression.fromJson(progression.toSaveData().toJson()),
        )
        ..restoreTurretModulesFromSaveData(
          SavedTurretModuleInventory.fromJson(
            progression.toTurretModuleSaveData().toJson(),
          ),
        );
      expect(
        restored.claimDailyQuestAllCompleteReward(nowMillis: nowMillis),
        isFalse,
      );
      expect(restored.freeDiamonds, 40);
      expect(restored.turretModuleTickets, 1);
    },
  );

  test('daily attendance grants twenty free diamonds once and resets', () {
    final firstDay = DateTime.utc(2026, 6, 8).millisecondsSinceEpoch;
    final nextDay = DateTime.utc(2026, 6, 9).millisecondsSinceEpoch;
    final progression = RunProgression();

    expect(progression.claimDailyAttendanceReward(nowMillis: firstDay), isTrue);
    expect(
      progression.claimDailyAttendanceReward(nowMillis: firstDay),
      isFalse,
    );
    expect(progression.freeDiamonds, dailyAttendanceRewardDiamonds);

    final saved = SavedProgression.fromJson(progression.toSaveData().toJson());
    final restored = RunProgression()..restoreFromSaveData(saved);
    expect(restored.dailyAttendanceRewardClaimed, isTrue);
    expect(restored.claimDailyAttendanceReward(nowMillis: nextDay), isTrue);
    expect(restored.freeDiamonds, dailyAttendanceRewardDiamonds * 2);
  });

  test('weekly quests grant configured rewards once and persist state', () {
    final nowMillis = DateTime.utc(2026, 6, 8).millisecondsSinceEpoch;
    final progression = RunProgression();

    for (final entry in gameWeeklyQuestDefinitions.entries) {
      progression.recordDailyQuestProgress(
        entry.key,
        amount: entry.value.targetCount,
        nowMillis: nowMillis,
      );
      expect(
        progression.applyWeeklyQuestRewardReceipt(
          entry.key,
          weekKey: progression.weeklyQuestWeekKey,
          rewardDiamonds: entry.value.rewardDiamonds,
        ),
        isTrue,
      );
      expect(
        progression.applyWeeklyQuestRewardReceipt(
          entry.key,
          weekKey: progression.weeklyQuestWeekKey,
          rewardDiamonds: entry.value.rewardDiamonds,
        ),
        isFalse,
      );
    }

    expect(progression.completedWeeklyQuestCount, 4);
    expect(
      progression.applyWeeklyQuestAllCompleteRewardReceipt(
        weekKey: progression.weeklyQuestWeekKey,
        rewardDiamonds: weeklyQuestAllCompleteRewardDiamonds,
        rewardModuleTickets: weeklyQuestAllCompleteRewardModuleTickets,
      ),
      isTrue,
    );
    expect(
      progression.applyWeeklyQuestAllCompleteRewardReceipt(
        weekKey: progression.weeklyQuestWeekKey,
        rewardDiamonds: weeklyQuestAllCompleteRewardDiamonds,
        rewardModuleTickets: weeklyQuestAllCompleteRewardModuleTickets,
      ),
      isFalse,
    );
    expect(progression.freeDiamonds, 260);
    expect(progression.turretModuleTickets, 4);

    final saved = SavedProgression.fromJson(progression.toSaveData().toJson());
    final savedTurretModules = SavedTurretModuleInventory.fromJson(
      progression.toTurretModuleSaveData().toJson(),
    );
    final restored = RunProgression()
      ..restoreFromSaveData(saved)
      ..restoreTurretModulesFromSaveData(savedTurretModules);
    expect(restored.weeklyQuestProgress, progression.weeklyQuestProgress);
    expect(
      restored.claimedWeeklyQuestRewards,
      progression.claimedWeeklyQuestRewards,
    );
    expect(restored.weeklyQuestAllCompleteClaimed, isTrue);
    expect(restored.freeDiamonds, 260);
    expect(restored.turretModuleTickets, 4);
  });

  test(
    'weekly rewards only apply from a receipt for the current saved week',
    () {
      final nowMillis = DateTime.utc(2026, 6, 8).millisecondsSinceEpoch;
      final progression = RunProgression();
      progression.recordDailyQuestProgress(
        DailyQuestType.clearWaves,
        amount:
            gameWeeklyQuestDefinitions[DailyQuestType.clearWaves]!.targetCount,
        nowMillis: nowMillis,
      );

      expect(
        progression.applyWeeklyQuestRewardReceipt(
          DailyQuestType.clearWaves,
          weekKey: progression.weeklyQuestWeekKey - 1,
          rewardDiamonds: 9999,
        ),
        isFalse,
      );
      expect(progression.freeDiamonds, 0);
      expect(progression.claimedWeeklyQuestRewards, isEmpty);
    },
  );

  test('weekly attendance counts distinct days and resets on Monday', () {
    final beforeWeeklyReset = DateTime.utc(
      2026,
      6,
      7,
      19,
      59,
    ).millisecondsSinceEpoch;
    final afterWeeklyReset = DateTime.utc(
      2026,
      6,
      7,
      20,
    ).millisecondsSinceEpoch;
    expect(
      RunProgression.weeklyQuestWeekKeyFor(beforeWeeklyReset),
      isNot(RunProgression.weeklyQuestWeekKeyFor(afterWeeklyReset)),
    );

    final monday = DateTime.utc(2026, 6, 8).millisecondsSinceEpoch;
    final progression = RunProgression();

    for (var day = 0; day < weeklyAttendanceTargetDays; day++) {
      final nowMillis = monday + day * const Duration(days: 1).inMilliseconds;
      progression.refreshDailyQuests(nowMillis: nowMillis);
      progression.refreshDailyQuests(nowMillis: nowMillis);
    }

    expect(progression.weeklyAttendanceDayKeys.length, 5);
    expect(
      progression.applyWeeklyAttendanceRewardReceipt(
        weekKey: progression.weeklyQuestWeekKey,
        rewardDiamonds: weeklyAttendanceRewardDiamonds,
      ),
      isTrue,
    );
    expect(
      progression.applyWeeklyAttendanceRewardReceipt(
        weekKey: progression.weeklyQuestWeekKey,
        rewardDiamonds: weeklyAttendanceRewardDiamonds,
      ),
      isFalse,
    );
    expect(progression.freeDiamonds, weeklyAttendanceRewardDiamonds);

    progression.refreshDailyQuests(
      nowMillis: monday + const Duration(days: 7).inMilliseconds,
    );
    expect(progression.weeklyAttendanceDayKeys.length, 1);
    expect(progression.weeklyAttendanceRewardClaimed, isFalse);
    expect(progression.weeklyQuestProgress, isEmpty);
  });

  test('daily quests reset at KST five and block clock rollback claims', () {
    final beforeReset = DateTime.utc(2026, 6, 5, 19, 59).millisecondsSinceEpoch;
    final afterReset = DateTime.utc(2026, 6, 5, 20).millisecondsSinceEpoch;
    final progression = RunProgression();

    progression.recordDailyQuestProgress(
      DailyQuestType.killEnemies,
      amount: 100,
      nowMillis: beforeReset,
    );
    final previousDayKey = progression.dailyQuestDayKey;

    expect(progression.refreshDailyQuests(nowMillis: afterReset), isTrue);
    expect(progression.dailyQuestDayKey, isNot(previousDayKey));
    expect(progression.dailyQuestProgress, isEmpty);
    expect(progression.dailyQuestClockRollbackDetected, isFalse);
    expect(progression.lastDailyQuestSeenMillis, afterReset);

    progression.refreshDailyQuests(nowMillis: afterReset + 3600000);
    progression.recordDailyQuestProgress(
      DailyQuestType.killEnemies,
      amount: 100,
      nowMillis: afterReset,
    );

    expect(progression.dailyQuestClockRollbackDetected, isTrue);
    expect(
      progression.claimDailyQuestReward(
        DailyQuestType.killEnemies,
        nowMillis: afterReset,
      ),
      isFalse,
    );
    expect(progression.freeDiamonds, 0);
  });

  test('same-day clock advances checkpoint without quest state change', () {
    final initialMillis = DateTime.utc(2026, 6, 8).millisecondsSinceEpoch;
    final progression = RunProgression();

    expect(progression.refreshDailyQuests(nowMillis: initialMillis), isTrue);
    expect(progression.lastDailyQuestSeenMillis, initialMillis);

    expect(
      progression.refreshDailyQuests(nowMillis: initialMillis + 1000),
      isFalse,
    );
    expect(progression.lastDailyQuestSeenMillis, initialMillis);

    expect(
      progression.refreshDailyQuests(nowMillis: initialMillis + 60000),
      isFalse,
    );
    expect(progression.lastDailyQuestSeenMillis, initialMillis + 60000);
  });

  test(
    'routine frames do not publish or immediately save clock progress',
    () async {
      final repository = _CountingSaveRepository();
      final game = RuneNexusGame(saveRepository: repository);
      game.onGameResize(Vector2(400, 800));
      await game.onLoad();
      await game.saveNow();

      repository.saveCalls = 0;
      var snapshotNotifications = 0;
      game.snapshotNotifier.addListener(() {
        snapshotNotifications++;
      });

      for (var frame = 0; frame < 30; frame++) {
        await Future<void>.delayed(const Duration(milliseconds: 2));
        game.update(1 / 30);
      }

      expect(snapshotNotifications, 0);
      expect(repository.saveCalls, 0);
    },
  );

  test('daily quests track wave, boss, enemy, and run upgrades', () async {
    final game = RuneNexusGame(
      saveRepository: MemorySaveRepository(),
      waves: const [
        WaveDefinition(
          round: 1,
          previewText: 'test',
          groups: [],
          clearRewardGold: 0,
        ),
      ],
    );

    game.onGameResize(Vector2(400, 800));
    await game.onLoad();

    game.buyRunUpgrade(RunUpgradeType.towerDamage);
    expect(
      game.snapshotNotifier.value.dailyQuestProgress[DailyQuestType
          .buyRunUpgrades],
      1,
    );

    final normal = EnemyComponent(
      definition: gameEnemies[EnemyType.normal]!,
      maxHp: 1,
      path: [Vector2.zero(), Vector2(1, 0)],
      game: game,
    );
    game.registerEnemy(normal);
    acknowledgeNativeKill(game, normal);

    final boss = EnemyComponent(
      definition: gameEnemies[EnemyType.boss]!,
      maxHp: 1,
      path: [Vector2.zero(), Vector2(1, 0)],
      game: game,
    );
    game.registerEnemy(boss);
    acknowledgeNativeKill(game, boss);

    expect(
      game.snapshotNotifier.value.dailyQuestProgress[DailyQuestType
          .killEnemies],
      2,
    );
    expect(
      game.snapshotNotifier.value.dailyQuestProgress[DailyQuestType.killBosses],
      1,
    );

    game.startNextWave();
    acknowledgeNativeWaveCompleted(game);

    expect(
      game.snapshotNotifier.value.dailyQuestProgress[DailyQuestType.clearWaves],
      1,
    );
    expect(
      game.snapshotNotifier.value.weeklyQuestProgress[DailyQuestType
          .buyRunUpgrades],
      1,
    );
    expect(
      game.snapshotNotifier.value.weeklyQuestProgress[DailyQuestType
          .killEnemies],
      2,
    );
    expect(
      game.snapshotNotifier.value.weeklyQuestProgress[DailyQuestType
          .killBosses],
      1,
    );
    expect(
      game.snapshotNotifier.value.weeklyQuestProgress[DailyQuestType
          .clearWaves],
      1,
    );
  });
}

class _CountingSaveRepository implements SaveRepository {
  GameSaveData? data;
  int saveCalls = 0;

  @override
  Future<GameSaveData?> load() async => data;

  @override
  Future<void> save(GameSaveData data) async {
    saveCalls++;
    this.data = data;
  }

  @override
  Future<void> clear() async {
    data = null;
  }
}
