import 'helpers/game_balance_test_helpers.dart';
import 'helpers/native_game_test_driver.dart';

// Native simulation coverage moved with its owner:
// godot/verify_native_wave_core.gd: guardian targeting/cooldown/haste,
// attack synchronization, rift durability targeting/refresh/tier bonus and
// saved third-activation power. These no longer call a Dart combat loop.
// godot/verify_native_core_defense.gd: damage restoration, multiplicative
// mitigation, emergency charge eligibility/once-per-round and final defense.
// This file retains app configuration, reward, preset and save contracts.
void main() {
  test('core output passives amplify guardian beam power', () async {
    final repository = MemorySaveRepository()
      ..data = saveWithCorePassiveRun(
        nexusHp: 20,
        roundIndex: 0,
        completedRounds: 0,
        phase: GamePhase.wave,
        totalCorePoints: 100,
        corePassiveNodeRanks: const {
          CorePassiveNodeId.attackOutput: 5,
          CorePassiveNodeId.attackFocus: 3,
          CorePassiveNodeId.attackRiftMark: 3,
          CorePassiveNodeId.attackOverclock: 1,
        },
        coreCombatSkillStats: const SavedCoreCombatSkillStats(
          directDamageDealt: 0,
          bonusDamageDealt: 0,
          activationCount: 2,
        ),
      );
    final game = RuneNexusGame(
      saveRepository: repository,
      waves: const [
        WaveDefinition(
          round: 1,
          previewText: 'test',
          groups: [],
          clearRewardGold: 0,
        ),
      ],
    );
    game.onGameResize(Vector2(400, 800));
    await game.onLoad();
    game.continueRestoredRun();
    game.tryBuildTurret(const GridPoint(2, 0));

    final arrow = gameTurrets[TurretType.arrow]!;
    final baseBeamDamage = arrow.damage * arrow.attackRate * 5 * 0.08;
    expect(game.nexusCoreBeamDamage, closeTo(baseBeamDamage * 2.1875, 0.001));

    final bootstrap = game.buildNativeCombatCommand(9001)['bootstrap'] as Map;
    final config = bootstrap['coreConfig'] as Map;
    expect(
      (config['powerMultiplier'] as num) *
          (config['powerEveryThirdMultiplier'] as num),
      closeTo(2.1875, .001),
    );
    expect(((bootstrap['wave'] as Map)['core'] as Map)['activationCount'], 2);
  });

  test(
    'efficiency build and upgrade discounts follow dynamic turret diversity',
    () async {
      final repository = MemorySaveRepository()
        ..data = saveWithCorePassiveRun(
          nexusHp: 20,
          roundIndex: 0,
          completedRounds: 1,
          gold: 10000,
          unlockedStageCount: 7,
          clearedStageNumbers: const {1, 2, 3, 4, 5, 6},
          totalCorePoints: 100,
          corePassiveNodeRanks: maxEfficiencyPassiveRanks,
        );
      final game = EfficiencyModuleGame(saveRepository: repository);
      game.onGameResize(Vector2(400, 800));
      await game.onLoad();

      // 모듈 건설 할인 하한 적용 후 절약 설계를 별도 곱연산.
      expect(game.turretBuildCost(TurretType.arrow), 41);
      game.tryBuildTurret(const GridPoint(2, 0));
      game.selectTurretType(TurretType.cannon);
      game.tryBuildTurret(const GridPoint(3, 0));
      game.selectTurretType(TurretType.magic);
      game.tryBuildTurret(const GridPoint(0, 1));

      final beforeFourthTypeCost = game.turretBuildCost(TurretType.arrow);
      final fourthTypeCost = game.turretBuildCost(TurretType.frost);
      final goldBeforeFourthType = game.snapshotNotifier.value.gold;
      game.selectTurretType(TurretType.frost);
      game.tryBuildTurret(const GridPoint(2, 1));

      expect(beforeFourthTypeCost, 41);
      expect(
        goldBeforeFourthType - game.snapshotNotifier.value.gold,
        fourthTypeCost,
      );
      // 네 번째 종류 자체에는 미적용, 배치 완료 후 통합 전선 활성화.
      expect(game.turretBuildCost(TurretType.arrow), 35);

      game.refundSelectedTurret();
      expect(game.turretBuildCost(TurretType.arrow), 41);
      game.selectTurretType(TurretType.frost);
      game.tryBuildTurret(const GridPoint(2, 1));
      expect(game.turretBuildCost(TurretType.arrow), 35);

      game.selectTurretType(TurretType.sniper);
      game.tryBuildTurret(const GridPoint(3, 1));
      final arrow = game.turrets.singleWhere(
        (turret) => turret.definition.type == TurretType.arrow,
      );
      expect(arrow.levelUpCost, 31);
      expect(arrow.linkUpgradeCost, 51);

      tapBuildTile(game, const GridPoint(2, 0));
      final goldBeforeUpgrades = game.snapshotNotifier.value.gold;
      game.levelUpSelectedTurret();
      game.upgradeSelectedTurretLink();

      expect(game.snapshotNotifier.value.gold, goldBeforeUpgrades - 31 - 51);
      expect(arrow.investedGold, 41 + 31 + 51);
      expect(game.snapshotNotifier.value.selectedTurretRefundGold, 92);

      var expectedInvestedGold = arrow.investedGold;
      while (arrow.level < 5) {
        expectedInvestedGold += arrow.levelUpCost;
        game.levelUpSelectedTurret();
      }
      expect(arrow.linkUpgradeCost, 129);
      expectedInvestedGold += arrow.linkUpgradeCost;
      game.upgradeSelectedTurretLink();
      expect(arrow.investedGold, expectedInvestedGold);
      expect(arrow.slotLimit, 3);
    },
  );

  test(
    'trait engineering updates displayed and paid Gem Shard costs',
    () async {
      final repository = MemorySaveRepository()
        ..data = saveWithCorePassiveRun(
          nexusHp: 20,
          roundIndex: 0,
          completedRounds: 1,
          gold: 10000,
          gemShards: 100,
          totalCorePoints: 100,
          corePassiveNodeRanks: maxEfficiencyPassiveRanks,
        );
      final game = RuneNexusGame(saveRepository: repository);
      game.onGameResize(Vector2(400, 800));
      await game.onLoad();
      game.tryBuildTurret(const GridPoint(2, 0));
      game.levelUpSelectedTurret();
      game.levelUpSelectedTurret();

      var snapshot = game.snapshotNotifier.value;
      expect(snapshot.selectedTurretPrimaryTraitCost, 9);
      game.chooseSelectedTurretPrimaryTrait(TurretTraitType.lightweightBarrel);
      snapshot = game.snapshotNotifier.value;
      expect(snapshot.gemShards, 91);

      while (snapshot.selectedTurretLevel < 7) {
        game.levelUpSelectedTurret();
        snapshot = game.snapshotNotifier.value;
      }
      expect(snapshot.selectedTurretSecondaryTraitCost, 18);
      game.chooseSelectedTurretSecondaryTrait(
        snapshot.selectedTurretSecondaryTraitChoices.first,
      );

      expect(game.snapshotNotifier.value.gemShards, 73);
    },
  );

  test(
    'supply recovery multiplies the complete round clear Gold reward',
    () async {
      final repository = MemorySaveRepository()
        ..data = saveWithCorePassiveRun(
          nexusHp: 20,
          roundIndex: 0,
          completedRounds: 0,
          supplyUpgradeLevel: 2,
          runUpgradeLevels: const {RunUpgradeType.waveGold: 1},
          totalCorePoints: 20,
          corePassiveNodeRanks: const {
            CorePassiveNodeId.efficiencySaving: 3,
            CorePassiveNodeId.efficiencySupplyRecovery: 5,
          },
        );
      final game = RuneNexusGame(
        saveRepository: repository,
        waves: const [
          WaveDefinition(
            round: 1,
            previewText: 'test',
            groups: [],
            clearRewardGold: 10,
          ),
        ],
      );
      game.onGameResize(Vector2(400, 800));
      await game.onLoad();

      game.startNextWave();
      acknowledgeNativeWaveCompleted(game);

      // (기본 10 + 영구 2 + 런 4) * 1.15 = 18.4 -> 18
      expect(game.snapshotNotifier.value.gold, 188);

      final lowRankRepository = MemorySaveRepository()
        ..data = saveWithCorePassiveRun(
          nexusHp: 20,
          roundIndex: 0,
          completedRounds: 1,
          totalCorePoints: 10,
          corePassiveNodeRanks: const {
            CorePassiveNodeId.efficiencySaving: 3,
            CorePassiveNodeId.efficiencySupplyRecovery: 1,
          },
        );
      final lowRankGame = RuneNexusGame(
        saveRepository: lowRankRepository,
        waves: const [
          WaveDefinition(
            round: 1,
            previewText: 'test',
            groups: [],
            clearRewardGold: 23,
          ),
        ],
      );
      lowRankGame.onGameResize(Vector2(400, 800));
      await lowRankGame.onLoad();
      lowRankGame.startNextWave();
      acknowledgeNativeWaveCompleted(lowRankGame);

      expect(lowRankGame.snapshotNotifier.value.gold, 194);
    },
  );

  test(
    'gem spectrum uses equipped types and multiplies module Gem effects',
    () async {
      final repository = MemorySaveRepository()
        ..data = saveWithCorePassiveRun(
          nexusHp: 20,
          roundIndex: 0,
          completedRounds: 1,
          gold: 10000,
          unlockedStageCount: 7,
          clearedStageNumbers: const {1, 2, 3, 4, 5, 6},
          totalCorePoints: 100,
          corePassiveNodeRanks: maxEfficiencyPassiveRanks,
        );
      final game = EfficiencyModuleGame(saveRepository: repository);
      game.onGameResize(Vector2(400, 800));
      await game.onLoad();

      void buildWithGem(TurretType turretType, GridPoint point, GemType gem) {
        game.selectTurretType(turretType);
        game.tryBuildTurret(point);
        game.grantGem(gem);
        game.equipSelectedTurret(gem);
      }

      buildWithGem(TurretType.arrow, const GridPoint(2, 0), GemType.range);
      buildWithGem(
        TurretType.cannon,
        const GridPoint(3, 0),
        GemType.armorPiercing,
      );
      buildWithGem(
        TurretType.magic,
        const GridPoint(0, 1),
        GemType.elementalDamage,
      );
      final arrow = game.turrets.singleWhere(
        (turret) => turret.definition.type == TurretType.arrow,
      );
      final cannon = game.turrets.singleWhere(
        (turret) => turret.definition.type == TurretType.cannon,
      );

      expect(
        arrow.range,
        closeTo(
          gameTurrets[TurretType.arrow]!.range *
              (1 + 0.2 * 1.2 * 1.09) *
              game.boardDistanceScale,
          0.001,
        ),
      );
      expect(cannon.ignoresArmorReduction, isTrue);

      game.removeSelectedTurretGemSlot();
      expect(
        arrow.range,
        closeTo(
          gameTurrets[TurretType.arrow]!.range *
              (1 + 0.2 * 1.2) *
              game.boardDistanceScale,
          0.001,
        ),
      );
      game.equipSelectedTurret(GemType.elementalDamage);

      buildWithGem(
        TurretType.frost,
        const GridPoint(2, 1),
        GemType.attackSpeed,
      );
      expect(
        arrow.range,
        closeTo(
          gameTurrets[TurretType.arrow]!.range *
              (1 + 0.2 * 1.2 * 1.12) *
              game.boardDistanceScale,
          0.001,
        ),
      );

      buildWithGem(
        TurretType.sniper,
        const GridPoint(3, 1),
        GemType.criticalChance,
      );
      buildWithGem(TurretType.lightning, const GridPoint(4, 1), GemType.chain);
      final lightning = game.turrets.singleWhere(
        (turret) => turret.definition.type == TurretType.lightning,
      );
      expect(
        arrow.range,
        closeTo(
          gameTurrets[TurretType.arrow]!.range *
              (1 + 0.2 * 1.2 * 1.18) *
              game.boardDistanceScale,
          0.001,
        ),
      );
      expect(lightning.lightningChainMaxJumps, 4);
    },
  );

  test('rift mark core skill unlocks with chapter two', () {
    final earlyProgression = RunProgression();
    expect(
      earlyProgression.equipCoreCombatSkill(CoreCombatSkill.riftMark),
      isFalse,
    );
    expect(earlyProgression.coreCombatSkill, CoreCombatSkill.guardianBeam);

    final chapterTwoProgression = RunProgression()
      ..restoreFromSaveData(
        const SavedProgression(
          runes: 0,
          lastRunRuneReward: 0,
          startingGoldUpgradeLevel: 0,
          nexusHpUpgradeLevel: 0,
          supplyUpgradeLevel: 0,
          fireTrainingUpgradeLevel: 0,
          criticalChanceUpgradeLevel: 0,
          criticalDamageUpgradeLevel: 0,
          killGoldUpgradeLevel: 0,
          emergencySaleUpgradeLevel: 0,
          unlockedStageCount: 6,
          bestRoundsByStage: {},
          clearedStageNumbers: {1, 2, 3, 4, 5},
          researchLevels: {},
          researchElapsedMillis: {},
          activeResearches: [],
        ),
      );

    expect(
      chapterTwoProgression.equipCoreCombatSkill(CoreCombatSkill.riftMark),
      isTrue,
    );
    expect(chapterTwoProgression.coreCombatSkill, CoreCombatSkill.riftMark);
  });

  test('rift mark state is saved and restored', () async {
    final repository = MemorySaveRepository()
      ..data = saveWithCorePassiveRun(
        nexusHp: 20,
        roundIndex: 0,
        completedRounds: 0,
        unlockedStageCount: 6,
        clearedStageNumbers: const {1, 2, 3, 4, 5},
        coreCombatSkill: CoreCombatSkill.riftMark,
      );
    final game = RuneNexusGame(
      saveRepository: repository,
      waves: const [
        WaveDefinition(
          round: 1,
          previewText: 'test',
          groups: [],
          clearRewardGold: 0,
        ),
      ],
    );
    game.onGameResize(Vector2(400, 800));
    await game.onLoad();
    game.startNextWave();

    final enemy = durabilityEnemy(game, hp: 100, progress: 10);
    enemy.applyNativeCombatState({
      ...enemy.nativeCombatState(0),
      'riftMarkDamageAmplification': .25,
      'riftMarkRemaining': 5.0,
    });
    game.registerEnemy(enemy);
    await game.saveNow();

    final saved = repository.data!;
    expect(saved.activeRun!.runCoreCombatSkill, CoreCombatSkill.riftMark);
    expect(
      saved.activeRun!.enemies.single.riftMarkRemaining,
      closeTo(5, 0.001),
    );

    final restoredRepository = MemorySaveRepository()..data = saved;
    final restored = RuneNexusGame(
      saveRepository: restoredRepository,
      waves: const [
        WaveDefinition(
          round: 1,
          previewText: 'test',
          groups: [],
          clearRewardGold: 0,
        ),
      ],
    );
    restored.onGameResize(Vector2(400, 800));
    await restored.onLoad();
    expect(restored.enemies.single.hasRiftMark, isTrue);
    expect(restored.enemies.single.riftMarkDamageAmplification, 0.25);
  });

  test(
    'core combat skill stats are saved and restored with legacy fallback',
    () {
      final saved = saveWithCorePassiveRun(
        nexusHp: 20,
        roundIndex: 1,
        completedRounds: 1,
        coreCombatSkillStats: const SavedCoreCombatSkillStats(
          directDamageDealt: 12.5,
          bonusDamageDealt: 7.25,
          activationCount: 3,
        ),
      );

      final restored = GameSaveData.fromJson(saved.toJson())!;
      expect(
        restored.activeRun!.runCoreCombatSkillStats.directDamageDealt,
        12.5,
      );
      expect(
        restored.activeRun!.runCoreCombatSkillStats.bonusDamageDealt,
        7.25,
      );
      expect(restored.activeRun!.runCoreCombatSkillStats.activationCount, 3);

      final legacyJson = Map<String, Object?>.of(saved.toJson());
      final legacyRunJson = Map<String, Object?>.of(
        legacyJson['activeRun']! as Map<String, Object?>,
      )..remove('runCoreCombatSkillStats');
      legacyJson['activeRun'] = legacyRunJson;
      final legacy = GameSaveData.fromJson(legacyJson)!;
      expect(legacy.activeRun!.runCoreCombatSkillStats.directDamageDealt, 0);
      expect(legacy.activeRun!.runCoreCombatSkillStats.bonusDamageDealt, 0);
      expect(legacy.activeRun!.runCoreCombatSkillStats.activationCount, 0);
    },
  );

  test(
    'nexus core beam stays inactive when combat skill is unequipped',
    () async {
      final game = RuneNexusGame(
        saveRepository: MemorySaveRepository(),
        waves: const [
          WaveDefinition(
            round: 1,
            previewText: 'test',
            groups: [],
            clearRewardGold: 0,
          ),
        ],
      );
      game.onGameResize(Vector2(400, 800));
      await game.onLoad();
      expect(game.unequipCoreCombatSkill(), isTrue);
      game.restartRun();
      game.tryBuildTurret(const GridPoint(2, 0));

      final enemy = EnemyComponent(
        definition: gameEnemies[EnemyType.normal]!,
        maxHp: 100,
        path: [Vector2.zero(), Vector2(200, 0)],
        game: game,
      )..distanceTravelled = 80;
      game.registerEnemy(enemy);
      game.startNextWave();
      game.registerEnemy(enemy);

      final nativeConfig =
          (game.buildNativeCombatCommand(9001)['bootstrap']
                  as Map)['coreConfig']
              as Map;

      expect(game.snapshotNotifier.value.nexusCoreBeamAvailable, isFalse);
      expect(nativeConfig['runSkill'], isNull);
      expect(game.nexusCoreBeamCooldownSeconds, 0);
      expect(enemy.hp, enemy.maxHp);
    },
  );

  test(
    'core combat changes after run start do not affect active run beam',
    () async {
      final game = RuneNexusGame(
        saveRepository: MemorySaveRepository(),
        waves: const [
          WaveDefinition(
            round: 1,
            previewText: 'test',
            groups: [],
            clearRewardGold: 0,
          ),
        ],
      );
      game.onGameResize(Vector2(400, 800));
      await game.onLoad();
      game.restartRun();
      game.tryBuildTurret(const GridPoint(2, 0));
      game.startNextWave();

      expect(game.unequipCoreCombatSkill(), isTrue);
      expect(game.snapshotNotifier.value.coreCombatSkill, isNull);

      final enemy = EnemyComponent(
        definition: gameEnemies[EnemyType.normal]!,
        maxHp: 100,
        path: [Vector2.zero(), Vector2(200, 0)],
        game: game,
      )..distanceTravelled = 80;
      game.registerEnemy(enemy);

      final nativeConfig =
          (game.buildNativeCombatCommand(9001)['bootstrap']
                  as Map)['coreConfig']
              as Map;

      expect(nativeConfig['runSkill'], 'guardianBeam');
    },
  );

  test(
    'active run core loadout is saved separately from core preset',
    () async {
      final repository = MemorySaveRepository();
      final game = RuneNexusGame(
        saveRepository: repository,
        waves: const [
          WaveDefinition(
            round: 1,
            previewText: 'test',
            groups: [],
            clearRewardGold: 0,
          ),
        ],
      );
      game.onGameResize(Vector2(400, 800));
      await game.onLoad();
      game.restartRun();
      game.tryBuildTurret(const GridPoint(2, 0));
      game.startNextWave();
      expect(game.unequipCoreCombatSkill(), isTrue);
      await game.saveNow();

      final saved = repository.data!;
      expect(saved.progression.coreCombatSkill, isNull);
      expect(saved.activeRun!.runCoreCombatSkill, CoreCombatSkill.guardianBeam);

      final restoredRepository = MemorySaveRepository()..data = saved;
      final restored = RuneNexusGame(
        saveRepository: restoredRepository,
        waves: const [
          WaveDefinition(
            round: 1,
            previewText: 'test',
            groups: [],
            clearRewardGold: 0,
          ),
        ],
      );
      restored.onGameResize(Vector2(400, 800));
      await restored.onLoad();
      restored.continueRestoredRun();

      final enemy = EnemyComponent(
        definition: gameEnemies[EnemyType.normal]!,
        maxHp: 100,
        path: [Vector2.zero(), Vector2(200, 0)],
        game: restored,
      )..distanceTravelled = 80;
      restored.registerEnemy(enemy);

      final nativeConfig =
          (restored.buildNativeCombatCommand(9001)['bootstrap']
                  as Map)['coreConfig']
              as Map;

      expect(restored.snapshotNotifier.value.coreCombatSkill, isNull);
      expect(nativeConfig['runSkill'], 'guardianBeam');
    },
  );

  test(
    'core progression defaults to guardian beam with empty passive tree',
    () {
      final saved = SavedProgression.fromJson(const <String, Object?>{
        'unlockedStageCount': 1,
      });
      final progression = RunProgression()..restoreFromSaveData(saved);

      expect(progression.coreCombatSkill, CoreCombatSkill.guardianBeam);
      expect(progression.totalCorePoints, 0);
      expect(progression.corePassiveNodeRanks, isEmpty);
      expect(
        progression.toSaveData().coreCombatSkill,
        CoreCombatSkill.guardianBeam,
      );
    },
  );

  test('core combat equipment can be saved and restored as empty', () {
    final saved = SavedProgression.fromJson(const <String, Object?>{
      'unlockedStageCount': 1,
      'coreCombatSkill': null,
    });
    final progression = RunProgression()..restoreFromSaveData(saved);

    expect(progression.coreCombatSkill, isNull);
    expect(progression.toSaveData().coreCombatSkill, isNull);
    expect(progression.toSaveData().toJson()['coreCombatSkill'], isNull);
    expect(
      progression.equipCoreCombatSkill(CoreCombatSkill.guardianBeam),
      isTrue,
    );
    expect(progression.coreCombatSkill, CoreCombatSkill.guardianBeam);
    expect(progression.unequipCoreCombatSkill(), isTrue);
    expect(progression.coreCombatSkill, isNull);
  });

  test('legacy passive slot JSON is ignored without compensation', () {
    final saved = SavedProgression.fromJson(const <String, Object?>{
      'corePassiveSlotTwoUnlocked': true,
      'corePassiveSlots': ['selfRepair', 'costSavingDesign'],
      'totalCorePoints': 0,
    });
    final progression = RunProgression()..restoreFromSaveData(saved);

    expect(progression.totalCorePoints, 0);
    expect(progression.corePassiveNodeRanks, isEmpty);
    expect(
      progression.toSaveData().toJson(),
      isNot(contains('corePassiveSlots')),
    );
  });

  test('core passive ranks are saved and restored', () {
    final progression = RunProgression()..grantCorePoints(20);
    expect(
      progression.setCorePassiveNodeRank(CorePassiveNodeId.attackHaste, 3),
      isTrue,
    );
    expect(
      progression.setCorePassiveNodeRank(CorePassiveNodeId.attackPrecompute, 2),
      isTrue,
    );

    final restored = RunProgression()
      ..restoreFromSaveData(progression.toSaveData());

    expect(restored.totalCorePoints, 20);
    expect(restored.spentCorePoints, 6);
    expect(restored.availableCorePoints, 14);
    expect(restored.corePassiveNodeRanks, progression.corePassiveNodeRanks);
  });

  test('core passive revision mismatch resets ranks but preserves points', () {
    final saved = SavedProgression.fromJson(<String, Object?>{
      'totalCorePoints': 20,
      'corePassiveTreeRevision': corePassiveTreeRevision + 1,
      'corePassiveNodeRanks': const {'attackHaste': 3},
      'claimedCorePointStageRewards': const [1, 2],
    });
    final progression = RunProgression()..restoreFromSaveData(saved);

    expect(progression.totalCorePoints, 20);
    expect(progression.corePassiveNodeRanks, isEmpty);
    expect(progression.claimedCorePointStageRewards, {1, 2});
  });

  test('Nexus HP save accepts legacy integers and preserves fractions', () {
    final fractionalSave = saveWithCorePassiveRun(
      nexusHp: 19.25,
      roundIndex: 1,
      completedRounds: 1,
      roundNexusHpLost: 1.75,
      emergencyChargeUsedThisRound: true,
      finalDefenseUsedThisRound: true,
    );
    final fractionalRestored = GameSaveData.fromJson(fractionalSave.toJson())!;

    expect(fractionalRestored.activeRun!.nexusHp, closeTo(19.25, 0.0001));
    expect(
      fractionalRestored.activeRun!.roundNexusHpLost,
      closeTo(1.75, 0.0001),
    );
    expect(fractionalRestored.activeRun!.emergencyChargeUsedThisRound, isTrue);
    expect(fractionalRestored.activeRun!.finalDefenseUsedThisRound, isTrue);

    final legacyJson = fractionalSave.toJson();
    final legacyRunJson = Map<String, Object?>.of(
      legacyJson['activeRun']! as Map<String, Object?>,
    )..['nexusHp'] = 19;
    legacyJson['activeRun'] = legacyRunJson;
    final legacyRestored = GameSaveData.fromJson(legacyJson)!;
    expect(legacyRestored.activeRun!.nexusHp, closeTo(19, 0.0001));
  });

  test('every stage grants two core points once for thirty total', () {
    expect(
      gameStages.fold<int>(
        0,
        (sum, stage) => sum + stage.firstClearCorePointReward,
      ),
      30,
    );
    expect(
      gameStages.map((stage) => stage.firstClearCorePointReward),
      everyElement(2),
    );

    final progression = RunProgression();
    progression.finishRun(
      completedRounds: 40,
      success: true,
      stageNumber: 5,
      firstClearCorePointReward: 2,
    );
    expect(progression.totalCorePoints, 2);
    expect(progression.lastRunCorePointReward, 2);

    progression.finishRun(
      completedRounds: 40,
      success: true,
      stageNumber: 5,
      firstClearCorePointReward: 2,
    );
    expect(progression.totalCorePoints, 2);
    expect(progression.lastRunCorePointReward, 0);

    progression.finishRun(
      completedRounds: 10,
      success: false,
      stageNumber: 10,
      firstClearCorePointReward: 2,
    );
    expect(progression.totalCorePoints, 2);
    expect(progression.lastRunCorePointReward, 0);
  });

  test('only stage eleven first clear grants five module tickets', () {
    final rewardsByStage = {
      for (final stage in gameStages)
        if (stage.firstClearTurretModuleTicketReward > 0)
          stage.id: stage.firstClearTurretModuleTicketReward,
    };
    expect(rewardsByStage, {11: 5});

    final progression = RunProgression();
    progression.finishRun(
      completedRounds: 40,
      success: true,
      stageNumber: 11,
      firstClearTurretModuleTicketReward: 5,
    );
    expect(progression.turretModuleTickets, 5);
    expect(progression.lastRunTurretModuleTicketReward, 5);

    final saved = SavedProgression.fromJson(progression.toSaveData().toJson());
    final savedTurretModules = SavedTurretModuleInventory.fromJson(
      progression.toTurretModuleSaveData().toJson(),
    );
    final restored = RunProgression()
      ..restoreFromSaveData(saved)
      ..restoreTurretModulesFromSaveData(savedTurretModules);
    expect(restored.turretModuleTickets, 5);
    expect(restored.lastRunTurretModuleTicketReward, 5);

    restored.finishRun(
      completedRounds: 40,
      success: true,
      stageNumber: 11,
      firstClearTurretModuleTicketReward: 5,
    );
    expect(restored.turretModuleTickets, 5);
    expect(restored.lastRunTurretModuleTicketReward, 0);

    restored.finishRun(completedRounds: 40, success: true, stageNumber: 12);
    expect(restored.turretModuleTickets, 5);
    expect(restored.lastRunTurretModuleTicketReward, 0);
  });

  test('legacy clears receive retroactive core points only once', () async {
    final repository = MemorySaveRepository()
      ..data = saveWithCorePassiveRun(
        nexusHp: 20,
        roundIndex: 0,
        completedRounds: 0,
        unlockedStageCount: 6,
        clearedStageNumbers: const {1, 5},
      );
    final game = RuneNexusGame(saveRepository: repository);
    game.onGameResize(Vector2(400, 800));
    await game.onLoad();
    await game.saveNow();

    expect(game.snapshotNotifier.value.totalCorePoints, 4);
    expect(game.snapshotNotifier.value.lastRunCorePointReward, 0);
    expect(repository.data!.progression.claimedCorePointStageRewards, {1, 5});

    final restored = RuneNexusGame(saveRepository: repository);
    restored.onGameResize(Vector2(400, 800));
    await restored.onLoad();
    expect(restored.snapshotNotifier.value.totalCorePoints, 4);
    expect(restored.snapshotNotifier.value.lastRunCorePointReward, 0);
  });

  test(
    'defense passives increase maximum HP and recover fractional HP',
    () async {
      final repository = MemorySaveRepository()
        ..data = saveWithCorePassiveRun(
          nexusHp: 19,
          roundIndex: 4,
          completedRounds: 4,
          totalCorePoints: 30,
          corePassiveNodeRanks: const {
            CorePassiveNodeId.controlSelfRepair: 5,
            CorePassiveNodeId.controlRetarget: 5,
          },
        );
      final game = RuneNexusGame(
        waves: emptyWaves(5),
        saveRepository: repository,
      );
      game.onGameResize(Vector2(400, 800));
      await game.onLoad();

      expect(game.turretBuildCost(TurretType.arrow), 60);
      expect(game.snapshotNotifier.value.maxNexusHp, closeTo(25, 0.0001));
      game.startNextWave();
      acknowledgeNativeWaveCompleted(
        game,
        defense: {'hp': 19.75, 'roundHpLost': 0.0},
      );
      expect(game.snapshotNotifier.value.nexusHp, closeTo(19.75, 0.0001));
    },
  );

  test('restored defense round state persists and resets next round', () async {
    final repository = MemorySaveRepository()
      ..data = saveWithCorePassiveRun(
        nexusHp: 15,
        roundIndex: 0,
        completedRounds: 0,
        phase: GamePhase.wave,
        totalCorePoints: 50,
        corePassiveNodeRanks: const {
          CorePassiveNodeId.controlSelfRepair: 3,
          CorePassiveNodeId.controlRetarget: 3,
          CorePassiveNodeId.controlBufferShell: 3,
          CorePassiveNodeId.controlThreatSense: 3,
          CorePassiveNodeId.controlRearLock: 3,
          CorePassiveNodeId.controlEmergencyCharge: 3,
          CorePassiveNodeId.controlFinalLine: 1,
        },
        roundNexusHpLost: 2,
        emergencyChargeUsedThisRound: true,
        finalDefenseUsedThisRound: true,
      );
    final game = RuneNexusGame(
      waves: emptyWaves(2),
      saveRepository: repository,
    );
    game.onGameResize(Vector2(400, 800));
    await game.onLoad();

    expect(game.snapshotNotifier.value.phase, GamePhase.restored);
    game.continueRestoredRun();

    var arrivalIndex = 0;
    Future<void> reachCore() async {
      final enemy = EnemyComponent(
        definition: gameEnemies[EnemyType.normal]!,
        maxHp: 100,
        path: [Vector2.zero(), Vector2(500, 0)],
        game: game,
      );
      game.registerEnemy(enemy);
      final hp = [14.09, 15.5685, 14.6585][arrivalIndex];
      final lost = [2.91, 0.0, .91][arrivalIndex];
      acknowledgeNativeArrival(
        game,
        enemy,
        defense: {
          'hp': hp,
          'roundHpLost': lost,
          'emergencyChargeUsedThisRound': arrivalIndex != 1,
          'finalDefenseUsedThisRound': true,
        },
      );
      if (arrivalIndex == 2) {
        acknowledgeNativeState(
          game,
          core: {'cooldown': 3.25, 'emergencyChargeUsedThisRound': true},
        );
      }
      arrivalIndex++;
    }

    await reachCore();

    // 복원된 사용 상태로 무효화와 충전이 중복 적용되지 않는다.
    expect(game.snapshotNotifier.value.nexusHp, closeTo(14.09, 0.0001));
    expect(game.nexusCoreBeamCooldownSeconds, closeTo(5, 0.0001));
    await game.saveNow();
    expect(repository.data!.activeRun!.roundNexusHpLost, closeTo(2.91, 0.0001));
    expect(repository.data!.activeRun!.emergencyChargeUsedThisRound, isTrue);
    expect(repository.data!.activeRun!.finalDefenseUsedThisRound, isTrue);

    acknowledgeNativeWaveCompleted(
      game,
      defense: {
        'hp': 15.5685,
        'roundHpLost': 0.0,
        'emergencyChargeUsedThisRound': false,
        'finalDefenseUsedThisRound': false,
      },
    );

    // 복원된 손실량까지 손상 복원에 포함한 뒤 라운드 상태를 초기화한다.
    expect(game.snapshotNotifier.value.phase, GamePhase.preparation);
    expect(game.snapshotNotifier.value.nexusHp, closeTo(15.5685, 0.0001));
    game.startNextWave();

    await reachCore();
    expect(game.snapshotNotifier.value.nexusHp, closeTo(15.5685, 0.0001));
    expect(game.nexusCoreBeamCooldownSeconds, closeTo(5, 0.0001));

    await reachCore();
    expect(game.snapshotNotifier.value.nexusHp, closeTo(14.6585, 0.0001));
    expect(game.nexusCoreBeamCooldownSeconds, closeTo(3.25, 0.0001));
    await game.saveNow();
    expect(repository.data!.activeRun!.roundNexusHpLost, closeTo(0.91, 0.0001));
    expect(repository.data!.activeRun!.emergencyChargeUsedThisRound, isTrue);
    expect(repository.data!.activeRun!.finalDefenseUsedThisRound, isTrue);
  });
}
